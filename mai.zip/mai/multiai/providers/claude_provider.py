from __future__ import annotations

from dataclasses import dataclass

from multiai.providers.base import BaseProvider, ProviderError


@dataclass
class ClaudeProvider(BaseProvider):
    api_key: str
    model: str = "claude-sonnet-4-5"

    def __init__(self, api_key: str, timeout: int, max_tokens: int, model: str = "claude-sonnet-4-5"):
        super().__init__(name="claude", timeout=timeout, max_tokens=max_tokens)
        self.api_key = api_key
        self.model = model

    def generate(self, prompt: str) -> str:
        data = self._post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json",
            },
            json={
                "model": self.model,
                "max_tokens": self.max_tokens,
                "system": self.system_prompt(),
                "messages": [{"role": "user", "content": prompt}],
            },
        )
        try:
            content = data["content"]
            if content and isinstance(content, list):
                return content[0].get("text", str(data))
            raise ProviderError(self.name, f"Empty content in response: {data}")
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"Unexpected response shape: {data}") from exc
