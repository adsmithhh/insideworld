# providers/__init__.py
from __future__ import annotations

from multiai.providers.claude_provider import ClaudeProvider
from multiai.providers.deepseek_provider import DeepSeekProvider
from multiai.providers.gemini_provider import GeminiProvider
from multiai.providers.openai_provider import OpenAIProvider

_DEFAULT_TIMEOUT   = 60
_DEFAULT_MAX_TOKENS = 2000

ALL_PROVIDER_KEYS = ("openai", "deepseek", "claude", "gemini")


def build_providers(config, keys: tuple[str, ...] = ALL_PROVIDER_KEYS) -> dict:
    """
    Instantiate and return a {key: provider} dict for the requested keys.
    Skips providers whose API key is missing (logs a warning).
    """
    mapping = {
        "openai":   lambda: OpenAIProvider(
            api_key=config.api_keys["openai"],
            timeout=_DEFAULT_TIMEOUT,
            max_tokens=_DEFAULT_MAX_TOKENS,
        ),
        "deepseek": lambda: DeepSeekProvider(
            api_key=config.api_keys["deepseek"],
            timeout=_DEFAULT_TIMEOUT,
            max_tokens=_DEFAULT_MAX_TOKENS,
        ),
        "claude":   lambda: ClaudeProvider(
            api_key=config.api_keys["claude"],
            timeout=_DEFAULT_TIMEOUT,
            max_tokens=_DEFAULT_MAX_TOKENS,
        ),
        "gemini":   lambda: GeminiProvider(
            api_key=config.api_keys["gemini"],
            timeout=_DEFAULT_TIMEOUT,
            max_tokens=_DEFAULT_MAX_TOKENS,
        ),
    }
    result = {}
    for key in keys:
        if key not in mapping:
            continue
        if not config.api_keys.get(key):
            print(f"[WARN] No API key for {key} — skipping")
            continue
        result[key] = mapping[key]()
    return result


def get_provider(config, name: str):
    """Return a single provider instance by name."""
    providers = build_providers(config, keys=(name,))
    if name not in providers:
        raise ValueError(f"Provider '{name}' unavailable (missing key or unknown name)")
    return providers[name]