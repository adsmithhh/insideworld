from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

import requests

from multiai.config import SYSTEM_PROMPT

RETRY_COUNT = 3
RETRY_DELAYS = (1, 2)  # seconds between attempts 1→2 and 2→3


class ProviderError(RuntimeError):
    def __init__(self, provider: str, message: str):
        super().__init__(f"{provider}: {message}")
        self.provider = provider
        self.message = message


@dataclass
class BaseProvider(ABC):
    name: str
    timeout: int
    max_tokens: int

    @abstractmethod
    def generate(self, prompt: str) -> str:
        raise NotImplementedError

    def _post(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        last_exc: Exception | None = None
        for attempt in range(RETRY_COUNT):
            try:
                response = requests.post(
                    url, headers=headers, json=json, timeout=self.timeout
                )
                response.raise_for_status()
                return response.json()
            except requests.HTTPError as exc:
                # 4xx = deterministic caller error — do not retry
                body = exc.response.text[:500] if exc.response is not None else ""
                raise ProviderError(
                    self.name,
                    f"HTTP {exc.response.status_code if exc.response else 'unknown'} {body}",
                ) from exc
            except requests.RequestException as exc:
                last_exc = exc
                if attempt < RETRY_COUNT - 1:
                    time.sleep(RETRY_DELAYS[attempt])
            except ValueError:
                raise ProviderError(self.name, "Invalid JSON response")
        raise ProviderError(
            self.name, f"Failed after {RETRY_COUNT} attempts: {last_exc}"
        )

    @staticmethod
    def system_prompt() -> str:
        return SYSTEM_PROMPT
