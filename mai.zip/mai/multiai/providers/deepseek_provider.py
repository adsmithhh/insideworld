from __future__ import annotations

from dataclasses import dataclass

from multiai.providers.base import BaseProvider, ProviderError


@dataclass
class DeepSeekProvider(BaseProvider):
    api_key: str
    model: str = "deepseek-chat"

    def __init__(self, api_key: str, timeout: int, max_tokens: int, model: str = "deepseek-chat"):
        super().__init__(name="deepseek", timeout=timeout, max_tokens=max_tokens)
        self.api_key = api_key
        self.model = model

    def generate(self, prompt: str) -> str:
        data = self._post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.model,
                "messages": [
                    {"role": "system", "content": self.system_prompt()},
                    {"role": "user", "content": prompt},
                ],
                "max_tokens": self.max_tokens,
            },
        )
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"Unexpected response shape: {data}") from exc
