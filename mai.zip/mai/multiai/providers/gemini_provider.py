from __future__ import annotations

from dataclasses import dataclass

from multiai.providers.base import BaseProvider, ProviderError


@dataclass
class GeminiProvider(BaseProvider):
    api_key: str
    model: str = "gemini-2.5-flash-preview-04-17"

    def __init__(self, api_key: str, timeout: int, max_tokens: int, model: str = "gemini-2.5-flash-preview-04-17"):
        super().__init__(name="gemini", timeout=timeout, max_tokens=max_tokens)
        self.api_key = api_key
        self.model = model

    def generate(self, prompt: str) -> str:
        data = self._post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}",
            json={
                "system_instruction": {"parts": [{"text": self.system_prompt()}]},
                "contents": [{"parts": [{"text": prompt}]}],
            },
        )
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"Unexpected response shape: {data}") from exc
