from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable
import re
import yaml

from multiai.models import SavedArtifact


def slugify(text: str, max_len: int = 48) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text[:max_len] or "question"


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_file(workspace: Path, filepath: str, max_chars: int = 3000) -> str | None:
    candidate = Path(filepath)
    if not candidate.is_absolute():
        candidate = workspace / filepath
    if not candidate.exists() or not candidate.is_file():
        return None
    content = candidate.read_text(encoding="utf-8")
    if len(content) > max_chars:
        content = content[:max_chars] + "\n...[truncated]..."
    return content


def collect_folder(workspace: Path, directory: str, max_chars_per_file: int = 4000, max_total: int = 20000) -> tuple[str | None, list[str]]:
    full_path = Path(directory)
    if not full_path.is_absolute():
        full_path = workspace / directory
    if not full_path.exists():
        return None, []
    all_files = sorted(f for f in full_path.rglob("*") if f.is_file())
    if not all_files:
        return None, []

    sections: list[str] = []
    included: list[str] = []
    total = 0
    for file in all_files:
        try:
            content = file.read_text(encoding="utf-8")
            if len(content) > max_chars_per_file:
                content = content[:max_chars_per_file] + "\n...[truncated]..."
            rel = file.relative_to(workspace) if file.is_relative_to(workspace) else file
            section = f"\n{'='*60}\nFILE: {rel}\n{'='*60}\n{content}"
            total += len(section)
            if total > max_total:
                sections.append("\n[Remaining files omitted — total limit reached]")
                break
            sections.append(section)
            included.append(str(rel))
        except Exception as exc:
            sections.append(f"\n[Could not read {file.name}: {exc}]")
    return "\n".join(sections), included


def create_question_bundle_dir(output_dir: Path, question: str) -> tuple[str, Path]:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    bundle = ensure_dir(output_dir / "questions" / f"question_{timestamp}_{slugify(question)}")
    return timestamp, bundle


def write_text(path: Path, content: str) -> None:
    ensure_dir(path.parent)
    path.write_text(content, encoding="utf-8")


def write_manifest(bundle_dir: Path, question: str, timestamp: str, workspace: Path, artifacts: Iterable[SavedArtifact], provider_models: dict[str, str]) -> Path:
    data = {
        "question": question,
        "timestamp": timestamp,
        "workspace": str(workspace),
        "models": [
            {
                "label": artifact.label,
                "key": artifact.key,
                "file": artifact.file.name,
                "status": artifact.status,
                "provider_model": provider_models.get(artifact.key, "unknown"),
            }
            for artifact in artifacts
        ],
    }
    manifest_path = bundle_dir / "manifest.yaml"
    write_text(manifest_path, yaml.safe_dump(data, sort_keys=False, allow_unicode=True))
    return manifest_path


def load_question_bundle(workspace: Path, bundle_dir: str) -> dict:
    bundle_path = Path(bundle_dir)
    if not bundle_path.is_absolute():
        bundle_path = workspace / bundle_dir
    manifest_file = bundle_path / "manifest.yaml"
    if not manifest_file.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_file}")
    manifest = yaml.safe_load(manifest_file.read_text(encoding="utf-8"))
    model_outputs = {}
    for item in manifest.get("models", []):
        key = item.get("key")
        file_name = item.get("file")
        if not key or not file_name:
            continue
        out_path = bundle_path / file_name
        model_outputs[key] = out_path.read_text(encoding="utf-8") if out_path.exists() else f"[Missing file: {file_name}]"
    manifest["model_outputs"] = model_outputs
    return manifest
