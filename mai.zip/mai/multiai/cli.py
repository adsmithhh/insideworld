from __future__ import annotations

import argparse
import sys
from pathlib import Path

from multiai.config import load_config, safe_resolve_within
from multiai.menu import run_menu
from multiai.providers.claude_provider import ClaudeProvider
from multiai.providers.deepseek_provider import DeepSeekProvider
from multiai.providers.gemini_provider import GeminiProvider
from multiai.providers.openai_provider import OpenAIProvider
from multiai.services.analyze import analyze_file, folder_report
from multiai.services.ask import ask_all, ask_file, ask_single, explain_project
from multiai.services.review import review_question_bundle
from multiai.services.self_test import run_self_tests
from multiai.services.synthesize import synthesize


def build_provider_registry(config):
    providers = {}
    provider_models = {}
    if config.openai_api_key:
        providers["openai"] = OpenAIProvider(config.openai_api_key, config.timeout, config.max_tokens)
        provider_models["openai"] = providers["openai"].model
    if config.deepseek_api_key:
        providers["deepseek"] = DeepSeekProvider(config.deepseek_api_key, config.timeout, config.max_tokens)
        provider_models["deepseek"] = providers["deepseek"].model
    if config.claude_api_key:
        providers["claude"] = ClaudeProvider(config.claude_api_key, config.timeout, config.max_tokens)
        provider_models["claude"] = providers["claude"].model
    if config.gemini_api_key:
        providers["gemini"] = GeminiProvider(config.gemini_api_key, config.timeout, config.max_tokens)
        provider_models["gemini"] = providers["gemini"].model
    return providers, provider_models


def require_provider(providers: dict, key: str):
    if key not in providers:
        raise ValueError(f"Provider not configured: {key}")
    return providers[key]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="multiai", description="Multi-AI CLI")
    parser.add_argument("--workspace", default=None, help="Project workspace root")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("analyze-file")
    p.add_argument("filename")

    p = sub.add_parser("folder-report")
    p.add_argument("directory")

    p = sub.add_parser("ask")
    p.add_argument("question")
    p.add_argument("--model", default="openai")

    p = sub.add_parser("ask-all")
    p.add_argument("question")

    p = sub.add_parser("ask-file")
    p.add_argument("filename")
    p.add_argument("question")
    p.add_argument("--model", default="openai")

    p = sub.add_parser("explain")
    p.add_argument("--model", default="openai")

    p = sub.add_parser("self-test")
    p.add_argument("test_name", nargs="?", default="all")

    p = sub.add_parser("synthesize")
    p.add_argument("input_dir")
    p.add_argument("output_name", nargs="?")

    p = sub.add_parser("review-question")
    p.add_argument("bundle_dir")
    p.add_argument("--model", default="claude")

    p = sub.add_parser("list")

    p = sub.add_parser("explore")
    p.add_argument("directory")

    sub.add_parser("menu")

    return parser


def _print_result(path: Path, body: str) -> None:
    print(f"\n{'='*72}")
    print(f"  SAVED: {path}")
    print(f"{'='*72}")
    print(body)
    print()


def _cmd_list(workspace: Path) -> None:
    py_files = sorted(workspace.rglob("*.py"))
    for f in py_files[:30]:
        print(f"  {f.relative_to(workspace)}")
    print(f"\nTotal: {len(py_files)} Python files")


def _cmd_explore(workspace: Path, directory: str) -> None:
    safe_dir = safe_resolve_within(workspace, directory)
    if safe_dir is None:
        raise PermissionError(f"Path outside workspace: {directory}")
    if not safe_dir.exists():
        raise FileNotFoundError(directory)
    if safe_dir.is_file():
        print(f"  {safe_dir} is a file — use analyze-file instead")
        return
    py_files   = list(safe_dir.rglob("*.py"))
    yaml_files = list(safe_dir.rglob("*.yaml")) + list(safe_dir.rglob("*.yml"))
    md_files   = list(safe_dir.rglob("*.md"))
    print(f"\nExploring: {directory}")
    print(f"  Python: {len(py_files)}  YAML: {len(yaml_files)}  MD: {len(md_files)}")
    for f in py_files[:10]:
        print(f"  {f.relative_to(safe_dir)}")


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    config = load_config(args.workspace)
    providers, provider_models = build_provider_registry(config)

    if args.command in ("list", "explore"):
        # No providers needed for filesystem commands
        if args.command == "list":
            _cmd_list(config.workspace)
        else:
            _cmd_explore(config.workspace, args.directory)
        return 0

    if args.command == "menu":
        tokens = run_menu(args.workspace)
        if not tokens:
            return 0
        # Re-parse the collected tokens and recurse through main
        workspace_prefix = ["--workspace", args.workspace] if args.workspace else []
        sys.argv = [sys.argv[0]] + workspace_prefix + tokens
        return main()

    if not providers:
        raise RuntimeError("No providers configured. Set at least one API key in .env")

    if args.command == "analyze-file":
        for f, body in analyze_file(config.workspace, providers, args.filename, config.output_dir):
            _print_result(f, body)
    elif args.command == "folder-report":
        for f, body in folder_report(config.workspace, providers, args.directory, config.output_dir):
            _print_result(f, body)
    elif args.command == "ask":
        provider = require_provider(providers, args.model)
        print(ask_single(config.workspace, provider, args.question))
    elif args.command == "ask-all":
        out_dir, manifest, _ = ask_all(config.workspace, providers, args.question, provider_models, config.output_dir)
        print(out_dir)
        print(manifest)
    elif args.command == "ask-file":
        provider = require_provider(providers, args.model)
        print(ask_file(config.workspace, provider, args.filename, args.question))
    elif args.command == "explain":
        provider = require_provider(providers, args.model)
        print(explain_project(config.workspace, provider))
    elif args.command == "self-test":
        for f, body in run_self_tests(config.workspace, providers, args.test_name, config.output_dir):
            _print_result(f, body)
    elif args.command == "synthesize":
        for f, body in synthesize(config.workspace, providers, args.input_dir, args.output_name, config.output_dir):
            _print_result(f, body)
    elif args.command == "review-question":
        provider = require_provider(providers, args.model)
        print(review_question_bundle(config.workspace, provider, args.bundle_dir, args.model))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())