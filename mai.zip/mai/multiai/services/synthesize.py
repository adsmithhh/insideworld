from __future__ import annotations

from pathlib import Path
from typing import Generator

from multiai.config import safe_resolve_within
from multiai.storage import ensure_dir, write_text


def build_synthesis_prompt(sections: list[str], input_dir: str) -> str:
    combined = "\n".join(sections)
    return (
        f"You are receiving {len(sections)} separate implementations of the same component,\n"
        "produced independently. You have no information about which system produced which.\n\n"
        "Your task is NOT to rank or evaluate them.\n"
        "Your task is to SYNTHESIZE — extract what is structurally sound from each\n"
        "and produce ONE unified implementation that contains the best elements of all.\n\n"
        "Synthesis rules:\n"
        "- Keep what is architecturally correct\n"
        "- Discard what is hallucinated or unsupported by the project context\n"
        "- Resolve conflicts by choosing the most grounded option\n"
        "- Use regime constants as strings: DORMANT, ACTIVE, DESTABILIZED, CORRECTIVE, SAFE_AWARE\n"
        "- Use math.isclose() for float comparisons\n"
        "- No hardcoded API keys\n"
        "- Connect entropy_calc.py and anchor_resolver.py using their actual function signatures:\n"
        "    entropy_bits(anchor_dict) -> float\n"
        "    prediction_salience(before, after) -> float\n"
        "    classify_conflict(anchors, injection) -> (conflict_type, diffs)\n"
        "    resolve(anchors, injection, diffs) -> dict\n\n"
        "Output: one complete, runnable Python file. Nothing else.\n\n"
        f"Implementations follow from {input_dir}:\n{combined}"
    )


def synthesize(workspace: Path, providers: dict, input_dir: str, output_name: str | None = None, output_dir: Path | None = None) -> Generator[tuple[Path, str], None, None]:
    full_path = safe_resolve_within(workspace, input_dir)
    if full_path is None:
        raise PermissionError(f"Directory outside workspace or inaccessible: {input_dir}")
    if not full_path.exists():
        raise FileNotFoundError(input_dir)

    txt_files = sorted(full_path.glob("*.txt"))
    if not txt_files:
        raise FileNotFoundError(f"No .txt files found in: {input_dir}")

    sections: list[str] = []
    for index, file in enumerate(txt_files, start=1):
        content = file.read_text(encoding="utf-8")
        stripped = "\n".join(line for line in content.splitlines() if not line.startswith("MODEL:"))
        sections.append(f"\n{'='*60}\nIMPLEMENTATION {index}\n{'='*60}\n{stripped}")

    prompt = build_synthesis_prompt(sections, input_dir)
    out_dir = ensure_dir((output_dir or workspace / "audit_results") / "synthesis")
    base_name = output_name or Path(input_dir).name
    for key, provider in providers.items():
        try:
            result = provider.generate(prompt)
        except Exception as exc:
            result = f"[ERROR] {key} failed: {exc}"
        body = f"# SYNTHESIS\n# MODEL: {key}\n# SOURCE: {input_dir}\n# {'='*56}\n\n{result}"
        out_file = out_dir / f"{base_name}_synthesis_{key}.py"
        write_text(out_file, body)
        yield out_file, body
