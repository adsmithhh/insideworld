from __future__ import annotations

from pathlib import Path

from multiai.config import safe_resolve_within


def list_files(workspace: Path, max_results: int = 30) -> list[Path]:
    py_files = sorted(workspace.rglob("*.py"))
    for f in py_files[:max_results]:
        print(f"  {f.relative_to(workspace)}")
    print(f"\nTotal: {len(py_files)} Python files")
    return py_files


def explore(workspace: Path, directory: str) -> dict:
    safe_dir = safe_resolve_within(workspace, directory)
    if safe_dir is None:
        raise PermissionError(f"Path outside workspace: {directory}")
    if not safe_dir.exists():
        raise FileNotFoundError(directory)
    if safe_dir.is_file():
        # Delegate to analyze — caller handles this
        return {"type": "file", "path": safe_dir}

    py_files   = list(safe_dir.rglob("*.py"))
    yaml_files = list(safe_dir.rglob("*.yaml")) + list(safe_dir.rglob("*.yml"))
    md_files   = list(safe_dir.rglob("*.md"))

    print(f"\nExploring: {directory}")
    print(f"  Python: {len(py_files)}  YAML: {len(yaml_files)}  MD: {len(md_files)}")
    for f in py_files[:10]:
        print(f"  {f.relative_to(safe_dir)}")

    return {
        "type": "directory",
        "path": safe_dir,
        "py": py_files,
        "yaml": yaml_files,
        "md": md_files,
    }