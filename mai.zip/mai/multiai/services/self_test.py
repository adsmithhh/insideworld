from __future__ import annotations

from pathlib import Path
from typing import Generator

from multiai.config import SELF_TESTS
from multiai.storage import ensure_dir, write_text


def run_self_tests(workspace: Path, providers: dict, test_name: str | None = None, output_dir: Path | None = None) -> Generator[tuple[Path, str], None, None]:
    if test_name is None or test_name == "all":
        tests_to_run = list(SELF_TESTS.keys())
    elif test_name in SELF_TESTS:
        tests_to_run = [test_name]
    else:
        raise ValueError(f"Unknown test: {test_name}. Available: {', '.join(SELF_TESTS)}, all")

    out_dir = ensure_dir((output_dir or workspace / "audit_results") / "self_tests")
    for test_key in tests_to_run:
        test = SELF_TESTS[test_key]
        for key, provider in providers.items():
            try:
                result = provider.generate(test["prompt"])
            except Exception as exc:
                result = f"[ERROR] {key} failed: {exc}"
            body = f"MODEL: {key}\nTEST: {test_key}\nDESCRIPTION: {test['description']}\n{'='*60}\n\n{result}"
            out_file = out_dir / f"{test_key}_{key}.txt"
            write_text(out_file, body)
            yield out_file, body
