from __future__ import annotations

from pathlib import Path

from multiai.config import safe_resolve_within
from multiai.storage import collect_folder, ensure_dir, write_text


def build_file_analysis_prompt(target_path: Path, content: str) -> str:
    return (
        "Analyze this Python file as a complete functional unit.\n"
        f"File: {target_path}\n\n"
        f"```python\n{content}\n```\n\n"
        "Produce a report covering:\n"
        "1. FUNCTION — what does this file do\n"
        "2. WORKING — what runs correctly\n"
        "3. BROKEN — what will crash or produce wrong results\n"
        "4. INCOMPLETE — what exists but is missing logic\n"
        "5. FIX LIST — ordered by priority"
    )


def build_folder_report_prompt(directory: str, combined: str) -> str:
    return (
        f"You are receiving the complete contents of folder: {directory}\n"
        "Treat this folder as a single entity — one system, not isolated files.\n\n"
        "Produce a unified report covering:\n"
        "1. SYSTEM PURPOSE\n2. STRUCTURAL INTEGRITY\n3. BROKEN\n"
        "4. INCOMPLETE\n5. ARCHITECTURAL GAPS\n6. PRIORITY FIX LIST\n\n"
        f"Folder contents:\n{combined}"
    )


from typing import Generator


def analyze_file(workspace: Path, providers: dict, filename: str, output_dir: Path) -> Generator[tuple[Path, str], None, None]:
    # If filename is an absolute path, use as-is; otherwise external_training_data
    # Strip quotes if present
    clean_filename = filename.strip('"')
    file_path = Path(clean_filename)
    if file_path.is_absolute():
        target_path = file_path
    else:
        # Support subfolders: prepend external_training_data to the full relative path
        target_path = safe_resolve_within(workspace, Path("external_training_data") / file_path)
    if target_path is None:
        raise PermissionError(f"Path outside workspace or inaccessible: {filename}")
    if target_path.is_dir():
        raise IsADirectoryError(str(target_path))
    if not target_path.exists():
        raise FileNotFoundError(str(target_path))

    content = target_path.read_text(encoding="utf-8")
    prompt = build_file_analysis_prompt(target_path, content)
    out_dir = ensure_dir(output_dir / "file_reports")
    for key, provider in providers.items():
        try:
            report = provider.generate(prompt)
        except Exception as exc:
            report = f"[ERROR] {key} failed: {exc}"
        body = f"MODEL: {key}\nFILE: {target_path}\n{'='*60}\n\n{report}"
        out_file = out_dir / f"{target_path.stem}_{key}.txt"
        write_text(out_file, body)
        yield out_file, body


def folder_report(workspace: Path, providers: dict, directory: str, output_dir: Path) -> Generator[tuple[Path, str], None, None]:
    # Strip quotes if present
    clean_directory = directory.strip('"')
    dir_path = Path(clean_directory)
    if dir_path.is_absolute():
        safe_dir = dir_path
    else:
        safe_dir = safe_resolve_within(workspace, Path("external_training_data") / dir_path)
    if safe_dir is None:
        raise PermissionError(f"Directory outside workspace: {directory}")
    combined, file_list = collect_folder(workspace, str(safe_dir))
    if not combined:
        raise FileNotFoundError(f"No files found in: {directory}")
    prompt = build_folder_report_prompt(str(safe_dir), combined)
    out_dir = ensure_dir(output_dir / "folder_reports")
    folder_name = Path(safe_dir).name
    for key, provider in providers.items():
        try:
            report = provider.generate(prompt)
        except Exception as exc:
            report = f"[ERROR] {key} failed: {exc}"
        body = f"MODEL: {key}\nFOLDER: {directory}\nFILES: {len(file_list)}\n{'='*60}\n\n{report}"
        out_file = out_dir / f"{folder_name}_{key}.txt"
        write_text(out_file, body)
        yield out_file, body
