from __future__ import annotations

from pathlib import Path

from multiai.storage import load_question_bundle, write_text


def build_review_prompt(bundle: dict) -> str:
    question = bundle.get("question", "[No question found]")
    timestamp = bundle.get("timestamp", "[No timestamp]")
    model_outputs = bundle.get("model_outputs", {})
    prompt = (
        "You are a language model reviewer. Your task is to review and critique the following answers to a question, each produced by a different model.\n"
        f"Question (from bundle, timestamp {timestamp}):\n{question}\n\n"
        "For each answer, provide:\n"
        "- Strengths\n- Weaknesses\n- Any errors or hallucinations\n- Suggestions for improvement\n\n"
        "Answers:\n"
    )
    for key, output in model_outputs.items():
        prompt += f"\n---\nModel: {key}\n---\n{output}\n"
    prompt += "\n\nAfter reviewing all, provide a summary: Which answer is most grounded, which is most speculative, and why?"
    return prompt


def review_question_bundle(workspace: Path, provider, bundle_dir: str, model_name: str) -> Path:
    bundle = load_question_bundle(workspace, bundle_dir)
    prompt = build_review_prompt(bundle)
    review = provider.generate(prompt)
    out_file = (Path(bundle_dir) if Path(bundle_dir).is_absolute() else workspace / bundle_dir) / f"review_{model_name}.txt"
    write_text(out_file, f"MODEL: {model_name}\nBUNDLE: {bundle_dir}\n{'='*60}\n\n{review}")
    return out_file
