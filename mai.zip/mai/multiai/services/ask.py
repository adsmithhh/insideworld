from __future__ import annotations

from pathlib import Path

from multiai.context_injection import auto_inject_context
from multiai.models import SavedArtifact
from multiai.storage import create_question_bundle_dir, ensure_dir, read_file, write_manifest, write_text


def ask_single(workspace: Path, provider, question: str) -> str:
    processed = auto_inject_context(question, workspace)
    return provider.generate(processed)


def ask_file(workspace: Path, provider, filename: str, question: str, max_chars: int = 3000) -> str:
    content = read_file(workspace, filename, max_chars=max_chars)
    if content is None:
        raise FileNotFoundError(filename)
    prompt = f"File: {filename}\n\n```python\n{content}\n```\n\nQuestion: {question}"
    return provider.generate(prompt)


def explain_project(workspace: Path, provider) -> str:
    readme = read_file(workspace, "README.md") or "No README.md found"
    prompt = f"Based on this README:\n\n{readme}\n\nWhat is this project about?"
    return provider.generate(prompt)


def ask_all(workspace: Path, providers: dict, question: str, provider_models: dict[str, str], output_dir: Path | None = None) -> tuple[Path, Path, list[SavedArtifact]]:
    processed = auto_inject_context(question, workspace)
    timestamp, out_dir = create_question_bundle_dir(output_dir or workspace / "audit_results", question)
    saved: list[SavedArtifact] = []
    for key, provider in providers.items():
        out_file = out_dir / f"{key}.txt"
        try:
            result = provider.generate(processed)
            status = "success"
            body = result
        except Exception as exc:
            status = "error"
            body = f"Error: {exc}"
        write_text(
            out_file,
            f"MODEL: {key}\nQUESTION: {question}\nTIMESTAMP: {timestamp}\n{'='*60}\n\n{body}",
        )
        saved.append(SavedArtifact(label=key, key=key, file=out_file, status=status))
    manifest = write_manifest(out_dir, question, timestamp, workspace, saved, provider_models)
    return out_dir, manifest, saved
