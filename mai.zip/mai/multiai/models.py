from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

ModelKey = Literal["openai", "deepseek", "claude", "gemini"]


@dataclass(frozen=True)
class ModelResult:
    provider: ModelKey
    status: Literal["success", "error"]
    content: str


@dataclass(frozen=True)
class SavedArtifact:
    label: str
    key: ModelKey
    file: Path
    status: Literal["success", "error"]
