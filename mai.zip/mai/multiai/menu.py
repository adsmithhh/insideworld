"""
Interactive menu for multiai.
Collects arguments, then re-dispatches through the existing CLI parser.
"""
from __future__ import annotations

import sys
from typing import Optional


# ── Command catalogue ─────────────────────────────────────────────────────────

_COMMANDS = [
    {
        "name": "analyze-file",
        "desc": "AI audit of a single file across all providers",
        "args": [
            {"label": "filename", "hint": "e.g. mymodule.py", "optional": False},
        ],
    },
    {
        "name": "folder-report",
        "desc": "AI audit of every file in a directory",
        "args": [
            {"label": "directory", "hint": "e.g. src/", "optional": False},
        ],
    },
    {
        "name": "ask",
        "desc": "Ask a single provider a question",
        "args": [
            {"label": "question", "hint": "any text", "optional": False},
            {"label": "model",    "hint": "openai | deepseek | claude | gemini", "optional": True, "default": "openai"},
        ],
    },
    {
        "name": "ask-all",
        "desc": "Ask all configured providers the same question",
        "args": [
            {"label": "question", "hint": "any text", "optional": False},
        ],
    },
    {
        "name": "ask-file",
        "desc": "Ask a provider a question about a specific file",
        "args": [
            {"label": "filename", "hint": "e.g. mymodule.py", "optional": False},
            {"label": "question", "hint": "any text",         "optional": False},
            {"label": "model",    "hint": "openai | deepseek | claude | gemini", "optional": True, "default": "openai"},
        ],
    },
    {
        "name": "explain",
        "desc": "Explain the whole project (scans workspace)",
        "args": [
            {"label": "model", "hint": "openai | deepseek | claude | gemini", "optional": True, "default": "openai"},
        ],
    },
    {
        "name": "synthesize",
        "desc": "Synthesize an audit_results directory into one report",
        "args": [
            {"label": "input_dir",   "hint": "e.g. audit_results/file_reports", "optional": False},
            {"label": "output_name", "hint": "leave blank for auto-name",        "optional": True,  "default": ""},
        ],
    },
    {
        "name": "review-question",
        "desc": "Cross-model review of a question bundle directory",
        "args": [
            {"label": "bundle_dir", "hint": "path to bundle dir", "optional": False},
            {"label": "model",      "hint": "openai | deepseek | claude | gemini", "optional": True, "default": "claude"},
        ],
    },
    {
        "name": "self-test",
        "desc": "Run internal self-tests",
        "args": [
            {"label": "test_name", "hint": "all | referential_binding | awareness_regression | phenomenal_boundary", "optional": True, "default": "all"},
        ],
    },
    {
        "name": "explore",
        "desc": "Explore a directory (file counts by type)",
        "args": [
            {"label": "directory", "hint": "e.g. multiai/services", "optional": False},
        ],
    },
    {
        "name": "list",
        "desc": "List Python files in the workspace",
        "args": [],
    },
]


# ── Rendering ─────────────────────────────────────────────────────────────────

_C = {
    "reset":  "\033[0m",
    "cyan":   "\033[96m",
    "yellow": "\033[93m",
    "white":  "\033[97m",
    "gray":   "\033[90m",
    "green":  "\033[92m",
    "red":    "\033[91m",
}

def _c(color: str, text: str) -> str:
    return f"{_C.get(color, '')}{text}{_C['reset']}"


def _render_menu() -> None:
    print()
    print(_c("cyan", "  ╔══════════════════════════════════════════════════╗"))
    print(_c("cyan", "  ║              M U L T I A I   M E N U            ║"))
    print(_c("cyan", "  ╚══════════════════════════════════════════════════╝"))
    print()
    for i, cmd in enumerate(_COMMANDS, 1):
        key  = _c("yellow", f"{i:>2}.")
        name = _c("white",  cmd["name"].ljust(18))
        desc = _c("gray",   cmd["desc"])
        print(f"  {key} {name} {desc}")
    print()
    print(_c("gray", "   0.  Exit"))
    print()


def _prompt_args(cmd: dict) -> Optional[list[str]]:
    """Collect argument values interactively. Returns list of CLI tokens or None on abort."""
    tokens: list[str] = []

    for arg in cmd["args"]:
        label    = arg["label"]
        hint     = arg["hint"]
        optional = arg["optional"]
        default  = arg.get("default", "")

        suffix = f" [{default}]" if optional and default else (" (optional, Enter to skip)" if optional else "")
        prompt_str = _c("cyan", f"    {label}") + _c("gray", f"  {hint}{suffix}") + "\n    > "

        try:
            val = input(prompt_str).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return None

        if val == "" and optional:
            val = default

        if val:
            tokens.append(val)

    return tokens


# ── Entry point ───────────────────────────────────────────────────────────────

def run_menu(workspace_arg: Optional[str] = None) -> list[str]:
    """
    Show the interactive menu and return a list of CLI tokens
    ready to be injected into sys.argv for re-parsing.
    Returns empty list if user exits.
    """
    _render_menu()

    try:
        choice = input(_c("cyan", "  Select") + " > ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return []

    if choice == "0" or choice == "":
        return []

    try:
        idx = int(choice) - 1
        if not (0 <= idx < len(_COMMANDS)):
            raise ValueError
    except ValueError:
        print(_c("red", "\n  Invalid selection.\n"))
        return []

    cmd = _COMMANDS[idx]
    print()
    print(_c("green", f"  ► {cmd['name']}") + _c("gray", f"  — {cmd['desc']}"))
    print()

    arg_tokens = _prompt_args(cmd)
    if arg_tokens is None:
        print(_c("gray", "  Cancelled.\n"))
        return []

    # Build final argv tokens
    result = [cmd["name"]] + [t for t in arg_tokens if t]
    return result
