from __future__ import annotations

import re
from pathlib import Path

from multiai.config import safe_resolve_within

PATH_PATTERN = r"[a-zA-Z]:\\[\\\w\s\-\.]+\.\w+|[\w\/\-.]+\.\w+"


def auto_inject_context(question: str, workspace: Path, max_chars: int = 10000) -> str:
    paths = re.findall(PATH_PATTERN, question)
    sections: list[str] = []
    for raw_path in paths:
        safe = safe_resolve_within(workspace, raw_path)
        if safe is None or not safe.is_file():
            continue
        try:
            content = safe.read_text(encoding="utf-8")[:max_chars]
        except Exception:
            continue
        sections.append(f"\n--- REFERENCE FILE: {safe} ---\n{content}\n")
    if sections:
        return "".join(sections) + f"\n\nBASED ON THE ABOVE CONTEXT, ANSWER: {question}"
    return question
