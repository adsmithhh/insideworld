import sys
import json
import sqlite3
import datetime
from pathlib import Path
from typing import Dict, List
import threading
import queue
import time

# Import your existing NPC recorder
from npc_speech_recorder import NPCSpeechRecorder

class AIModelRecorder:
    """
    Records AI model conversations and responses offline
    Extends NPC speech system to include AI models
    """
    
    def __init__(self, storage_path: str = None):
        self.recorder = NPCSpeechRecorder(storage_path)
        self.model_sessions = {}
        
        # Create AI models table
        self.init_ai_tables()
        
        print("🤖 AI Model Recorder initialized")
        print("📁 AI conversations will be stored offline")
    
    def init_ai_tables(self):
        """Initialize AI-specific tables"""
        conn = sqlite3.connect(self.recorder.db_path)
        cursor = conn.cursor()
        
        # AI Models table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ai_models (
                model_id TEXT PRIMARY KEY,
                model_name TEXT,
                provider TEXT,
                version TEXT,
                created_date TIMESTAMP,
                total_tokens_used INTEGER DEFAULT 0,
                total_calls INTEGER DEFAULT 0
            )
        ''')
        
        # AI Conversations table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ai_conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT,
                model_id TEXT,
                user_prompt TEXT,
                ai_response TEXT,
                prompt_tokens INTEGER,
                response_tokens INTEGER,
                response_time_ms INTEGER,
                emotion TEXT,
                timestamp TIMESTAMP,
                context TEXT,
                tags TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def register_model(self, model_id: str, model_name: str, 
                       provider: str, version: str = "1.0"):
        """Register an AI model for recording"""
        conn = sqlite3.connect(self.recorder.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO ai_models 
            (model_id, model_name, provider, version, created_date)
            VALUES (?, ?, ?, ?, ?)
        ''', (model_id, model_name, provider, version, datetime.datetime.now()))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Registered AI model: {model_name} ({model_id})")
    
    def record_ai_response(self, model_id: str, user_prompt: str, 
                           ai_response: str, emotion: str = "neutral",
                           context: str = None, tags: List[str] = None,
                           response_time_ms: int = 0,
                           tokens: Dict = None):
        """
        Record an AI model's response
        """
        conversation_id = f"ai_conv_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
        
        # Record as NPC speech (for unified view)
        self.recorder.record_speech(
            npc_id=model_id,
            speech_text=ai_response,
            npc_name=f"AI: {model_id}",
            context=f"Prompt: {user_prompt[:100]}... | {context}" if context else f"Prompt: {user_prompt[:100]}...",
            emotion=emotion,
            importance=3 if tokens and tokens.get('tokens', 0) > 1000 else 1,
            tags=(tags or []) + ['ai_response']
        )
        
        # Store in AI-specific table
        conn = sqlite3.connect(self.recorder.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO ai_conversations 
            (conversation_id, model_id, user_prompt, ai_response, 
             prompt_tokens, response_tokens, response_time_ms, 
             emotion, timestamp, context, tags)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            conversation_id,
            model_id,
            user_prompt,
            ai_response,
            tokens.get('prompt_tokens', 0) if tokens else 0,
            tokens.get('response_tokens', 0) if tokens else 0,
            response_time_ms,
            emotion,
            datetime.datetime.now(),
            context,
            json.dumps(tags or [])
        ))
        
        # Update model statistics
        cursor.execute('''
            UPDATE ai_models 
            SET total_calls = total_calls + 1,
                total_tokens_used = total_tokens_used + ?
            WHERE model_id = ?
        ''', (
            (tokens.get('prompt_tokens', 0) + tokens.get('response_tokens', 0)) if tokens else 0,
            model_id
        ))
        
        conn.commit()
        conn.close()
        
        print(f"📝 Recorded AI response from {model_id}")
        return conversation_id
    
    def get_model_stats(self, model_id: str = None):
        """Get statistics for AI models"""
        conn = sqlite3.connect(self.recorder.db_path)
        cursor = conn.cursor()
        
        if model_id:
            cursor.execute('''
                SELECT * FROM ai_models WHERE model_id = ?
            ''', (model_id,))
            result = cursor.fetchone()
        else:
            cursor.execute('''
                SELECT model_id, model_name, provider, total_calls, total_tokens_used
                FROM ai_models ORDER BY total_calls DESC
            ''')
            result = cursor.fetchall()
        
        conn.close()
        return result
    
    def get_conversation_history(self, model_id: str = None, limit: int = 50):
        """Get conversation history"""
        conn = sqlite3.connect(self.recorder.db_path)
        cursor = conn.cursor()
        
        if model_id:
            cursor.execute('''
                SELECT * FROM ai_conversations 
                WHERE model_id = ?
                ORDER BY timestamp DESC LIMIT ?
            ''', (model_id, limit))
        else:
            cursor.execute('''
                SELECT * FROM ai_conversations 
                ORDER BY timestamp DESC LIMIT ?
            ''', (limit,))
        
        conversations = []
        for row in cursor.fetchall():
            conversations.append({
                'id': row[0],
                'conversation_id': row[1],
                'model_id': row[2],
                'user_prompt': row[3],
                'ai_response': row[4][:200],  # Truncate for display
                'timestamp': row[9],
                'emotion': row[8]
            })
        
        conn.close()
        return conversations
    
    def export_ai_conversations(self, filename: str = None):
        """Export AI conversations to JSON"""
        if not filename:
            filename = f"ai_conversations_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        conn = sqlite3.connect(self.recorder.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM ai_conversations ORDER BY timestamp
        ''')
        
        conversations = []
        for row in cursor.fetchall():
            conversations.append({
                'conversation_id': row[1],
                'model_id': row[2],
                'user_prompt': row[3],
                'ai_response': row[4],
                'timestamp': str(row[9]),
                'emotion': row[8],
                'context': row[10]
            })
        
        conn.close()
        
        export_path = self.recorder.storage_path / filename
        with open(export_path, 'w', encoding='utf-8') as f:
            json.dump(conversations, f, indent=2, ensure_ascii=False)
        
        print(f"📄 Exported {len(conversations)} AI conversations to {export_path}")
        return export_path

# Create a wrapper for your existing multi_ai.py to auto-record
class RecordedAIModel:
    """Wrapper that records all AI interactions"""
    
    def __init__(self, model_id: str, model_name: str, 
                 call_function, provider: str = "unknown"):
        self.model_id = model_id
        self.model_name = model_name
        self.call_function = call_function
        self.recorder = AIModelRecorder()
        
        # Register this model
        self.recorder.register_model(model_id, model_name, provider)
    
    def ask(self, prompt: str, emotion: str = "neutral", **kwargs):
        """Ask the model and record the interaction"""
        start_time = time.time()
        
        try:
            # Call the actual model
            response = self.call_function(prompt, **kwargs)
            
            response_time = int((time.time() - start_time) * 1000)
            
            # Estimate tokens (rough estimate: 1 token ≈ 4 chars)
            prompt_tokens = len(prompt) // 4
            response_tokens = len(response) // 4
            
            # Record the interaction
            self.recorder.record_ai_response(
                model_id=self.model_id,
                user_prompt=prompt,
                ai_response=response,
                emotion=emotion,
                response_time_ms=response_time,
                tokens={
                    'prompt_tokens': prompt_tokens,
                    'response_tokens': response_tokens
                }
            )
            
            return response
            
        except Exception as e:
            print(f"Error calling model {self.model_id}: {e}")
            return f"Error: {e}"

def demo_ai_recording():
    """Demo recording AI interactions"""
    print("\n" + "="*60)
    print("🤖 AI Model Recording Demo")
    print("="*60)
    
    # Import your actual AI functions
    try:
        from multiai import call_openai, call_deepseek, call_claude, call_gemini
    except:
        print("⚠️ Could not import AI functions. Using mock responses.")
        # Mock functions for demo
        def mock_call(prompt):
            return f"AI response to: {prompt[:50]}..."
        
        call_openai = call_deepseek = call_claude = call_gemini = mock_call
    
    # Create recorded versions of your models
    recorded_models = {
        'openai': RecordedAIModel('openai_gpt4', 'ChatGPT GPT-4', call_openai, 'OpenAI'),
        'deepseek': RecordedAIModel('deepseek_chat', 'DeepSeek Chat', call_deepseek, 'DeepSeek'),
        'claude': RecordedAIModel('claude_haiku', 'Claude Haiku', call_claude, 'Anthropic'),
        'gemini': RecordedAIModel('gemini_flash', 'Gemini Flash', call_gemini, 'Google')
    }
    
    # Record some interactions
    test_prompts = [
        "What is the meaning of life?",
        "Explain quantum computing simply",
        "Write a haiku about programming"
    ]
    
    for prompt in test_prompts:
        print(f"\n💬 User: {prompt}")
        print("-" * 40)
        
        for name, model in recorded_models.items():
            response = model.ask(prompt, emotion="thoughtful")
            print(f"{name}: {response[:100]}...")
            time.sleep(0.5)
        
        print("\n" + "="*40)
    
    # Show statistics
    recorder = AIModelRecorder()
    stats = recorder.get_model_stats()
    print("\n📊 AI Model Statistics:")
    for stat in stats:
        print(f"  {stat[1]}: {stat[3]} calls, {stat[4]} tokens")
    
    # Export conversations
    recorder.export_ai_conversations()

if __name__ == "__main__":
    import time
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        demo_ai_recording()
    else:
        print("🤖 AI Model Recorder System")
        print("="*50)
        print("Commands:")
        print("  python ai_model_recorder.py demo  - Run demo")
        print("\nUse in your code:")
        print("  from ai_model_recorder import RecordedAIModel")
        print("  model = RecordedAIModel('my_model', 'My Model', call_function)")
        print("  response = model.ask('Hello!')")