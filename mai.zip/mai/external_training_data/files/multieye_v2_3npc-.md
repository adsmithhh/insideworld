multieye_v2_3_negcorr_npc:

  version: "2.3-negcorr"

  type: "npc_reasoning_module"

  purpose: "multi-perspective decision + perception scaffold for NPCs"

  npc_context:

    assumptions:

      - "NPC has local world-state perception"

      - "NPC has internal drives or goals"

      - "NPC operates under emotional/psi or entropy-like pressures"

    inputs:

      - "world_state_snapshot"

      - "npc_internal_state"

      - "recent_events"

      - "task_or_dilemma"

  angles:

    A1_semantic_logic:

      role: "what is happening from NPC’s point of view"

      output:

        - "NPC’s interpretation of the situation"

        - "key entities and relations"

      rules:

        - "use NPC-limited knowledge"

        - "do not assume meta/god view"

    A2_operational_logic:

      role: "how the situation works in practical terms"

      output:

        - "mechanical description of constraints"

        - "what the NPC can or cannot do"

      rules:

        - "focus on actions, rules, systems relevant to NPC"

    A3_symbolic_structure:

      role: "meaning and symbolic weight for NPC"

      output:

        - "which objects/events are symbolically charged"

        - "anchors tied to beliefs, factions, rituals"

      rules:

        - "track NPC-specific symbols (oaths, tokens, places)"

    A4_entropy_flow:

      role: "tension, chaos, unpredictability around NPC"

      output:

        - "entropy level (low/medium/high)"

        - "sources of instability (crowd, danger, emotional weather)"

      rules:

        - "flag when environment is unstable or saturated"

    A5_reasoning_geometry:

      role: "shape of NPC’s decision space"

      output:

        - "branching options, dead-ends, loops"

        - "is decision space narrow or wide"

      rules:

        - "represent choices as geometry: funnel, fork, maze"

    A6_alignment_pressure:

      role: "pressures from laws, factions, morals, scripts"

      output:

        - "what NPC is ‘supposed’ to do"

        - "what is forbidden or risky"

      rules:

        - "include social, doctrinal, and systemic constraints"

    A7_projection_dynamics:

      role: "NPC’s prediction of outcomes"

      output:

        - "likely consequences of each option"

        - "short vs long-term tradeoffs"

        - "confidence level"

      rules:

        - "stay inside NPC’s knowledge and intelligence"

    A8_continuity_field:

      role: "how this decision connects to NPC’s past and future arc"

      output:

        - "consistency with NPC history and role"

        - "impact on long-term character arc"

        - "continuity violations flagged"

      rules:

        - "respect previously established traits and choices"

    A9_uncertainty_lane:

      role: "explicit unknowns in NPC’s mind"

      output:

        - "what the NPC does not know"

        - "ambiguous signals"

        - "places where the world is ‘foggy’"

      rules:

        - "never hide uncertainty here; expose it"

  stabilizers:

    symbolic_stabilizer:

      detects:

        - "overloaded beliefs"

        - "contradictory loyalties"

        - "too many anchors for one NPC"

      responses:

        - "simplify symbolic load"

        - "prioritize core anchors"

        - "redirect excess to A9_uncertainty_lane"

    cross_angle_validators:

      - "check that actions in A7 respect constraints in A6"

      - "check that interpretations in A1 match NPC-limited info"

      - "check that continuity in A8 matches past NPC log"

  entropy_disclosure:

    angle_entropy:

      - "rate each angle: low/medium/high"

    global_entropy_trend:

      description: "overall stability of NPC situation"

      values: ["cooling", "stable", "heating", "critical"]

  decision_output:

    format:

      - "npc_chosen_action"

      - "rationale_summary"

      - "risk_level"

      - "continuity_impact"

      - "uncertainty_notes"

    rules:

      - "action must be consistent with A1–A8"

      - "if uncertainty is high, allow cautious or exploratory actions"